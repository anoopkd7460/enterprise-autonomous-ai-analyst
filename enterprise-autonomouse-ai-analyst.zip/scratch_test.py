from app.database.db import seed_sample_data
from app.agents.document_agent import index_document
from app.workflows.graph import answer_question

seed_sample_data()
index_document("data/sample/Q4_2024_Regional_Report.pdf", source_name="Q4_2024_Regional_Report")

answer = answer_question("Why did revenue fall in North India in Q4 2024?")
print("FINAL ANSWER:")
print(answer)